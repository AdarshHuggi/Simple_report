from sqlalchemy import (
    create_engine, Column, Integer, String, Text, Boolean, ForeignKey,
    TIMESTAMP
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

Base = declarative_base()

# ------------------------
# Reports (Main Metadata)
# ------------------------
class Report(Base):
    __tablename__ = "reports"

    report_id = Column(Integer, primary_key=True, autoincrement=True)
    report_name = Column(String(200), nullable=False)
    description = Column(Text)
    base_table = Column(String(200), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(TIMESTAMP)

    columns = relationship("ReportColumn", back_populates="report")
    joins = relationship("ReportJoin", back_populates="report")
    filters = relationship("ReportFilter", back_populates="report")
    groupings = relationship("ReportGrouping", back_populates="report")
    orderings = relationship("ReportOrdering", back_populates="report")
    expressions = relationship("ReportExpression", back_populates="report")
    logs = relationship("ReportLog", back_populates="report")


# ------------------------
# Report Columns
# ------------------------
class ReportColumn(Base):
    __tablename__ = "report_columns"

    column_id = Column(Integer, primary_key=True, autoincrement=True)
    report_id = Column(Integer, ForeignKey("reports.report_id"), nullable=False)
    column_alias = Column(String(200))
    db_column = Column(String(200), nullable=False)
    aggregation = Column(String(50))  # SUM, COUNT, etc
    display_order = Column(Integer)

    report = relationship("Report", back_populates="columns")


# ------------------------
# Report Joins
# ------------------------
class ReportJoin(Base):
    __tablename__ = "report_joins"

    join_id = Column(Integer, primary_key=True, autoincrement=True)
    report_id = Column(Integer, ForeignKey("reports.report_id"), nullable=False)
    join_type = Column(String(20), nullable=False)  # INNER, LEFT, RIGHT
    left_table = Column(String(200), nullable=False)
    left_column = Column(String(200), nullable=False)
    right_table = Column(String(200), nullable=False)
    right_column = Column(String(200), nullable=False)

    report = relationship("Report", back_populates="joins")


# ------------------------
# Report Filters
# ------------------------
class ReportFilter(Base):
    __tablename__ = "report_filters"

    filter_id = Column(Integer, primary_key=True, autoincrement=True)
    report_id = Column(Integer, ForeignKey("reports.report_id"), nullable=False)
    filter_name = Column(String(200), nullable=False)
    db_column = Column(String(200), nullable=False)
    operator = Column(String(20))  # =, >, <, BETWEEN, IN
    input_type = Column(String(50))  # dropdown, text, date

    report = relationship("Report", back_populates="filters")


# ------------------------
# Report Groupings
# ------------------------
class ReportGrouping(Base):
    __tablename__ = "report_groupings"

    group_id = Column(Integer, primary_key=True, autoincrement=True)
    report_id = Column(Integer, ForeignKey("reports.report_id"), nullable=False)
    db_column = Column(String(200), nullable=False)
    group_order = Column(Integer)

    report = relationship("Report", back_populates="groupings")


# ------------------------
# Report Orderings
# ------------------------
class ReportOrdering(Base):
    __tablename__ = "report_orderings"

    order_id = Column(Integer, primary_key=True, autoincrement=True)
    report_id = Column(Integer, ForeignKey("reports.report_id"), nullable=False)
    db_column = Column(String(200), nullable=False)
    sort_order = Column(String(10), nullable=False)  # ASC / DESC

    report = relationship("Report", back_populates="orderings")


# ------------------------
# Report Expressions (CASE, custom fields)
# ------------------------
class ReportExpression(Base):
    __tablename__ = "report_expressions"

    expr_id = Column(Integer, primary_key=True, autoincrement=True)
    report_id = Column(Integer, ForeignKey("reports.report_id"), nullable=False)
    expr_alias = Column(String(200), nullable=False)
    expression_sql = Column(Text, nullable=False)  # CASE WHEN ... END
    aggregation = Column(String(50))  # SUM, COUNT
    display_order = Column(Integer)

    report = relationship("Report", back_populates="expressions")


# ------------------------
# Report Logs (Execution)
# ------------------------
class ReportLog(Base):
    __tablename__ = "report_logs"

    log_id = Column(Integer, primary_key=True, autoincrement=True)
    report_id = Column(Integer, ForeignKey("reports.report_id"), nullable=False)
    executed_sql = Column(Text)
    executed_at = Column(TIMESTAMP)
    executed_by = Column(String(200))

    report = relationship("Report", back_populates="logs")


# ------------------------
# DB Setup
# ------------------------
def init_db(db_url="sqlite:///reports.db"):
    engine = create_engine(db_url, echo=True)
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)


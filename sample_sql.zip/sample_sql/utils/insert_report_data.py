from datetime import datetime
from models.model import Report,ReportColumn, ReportJoin, ReportFilter,init_db
from models.model import ReportGrouping, ReportOrdering, ReportExpression

Session = init_db()
session = Session()

def insert_report_metadata(
    session,
    report_name,
    description,
    base_table,
    columns=None,
    joins=None,
    filters=None,
    groupings=None,
    orderings=None,
    expressions=None
):
    """
    Inserts report metadata into all related tables in one go.
    """

    # 1. Create Report
    report = Report(
        report_name=report_name,
        description=description,
        base_table=base_table,
        is_active=True,
        created_at=datetime.now()
    )
    session.add(report)
    session.commit()  # need report_id for child tables

    # 2. Insert Columns
    if columns:
        for col in columns:
            session.add(ReportColumn(
                report_id=report.report_id,
                column_alias=col.get("alias"),
                db_column=col["db_column"],
                aggregation=col.get("aggregation"),
                display_order=col.get("order", 0)
            ))

    # 3. Insert Joins
    if joins:
        for j in joins:
            session.add(ReportJoin(
                report_id=report.report_id,
                join_type=j["join_type"],
                left_table=j["left_table"],
                left_column=j["left_column"],
                right_table=j["right_table"],
                right_column=j["right_column"]
            ))

    # 4. Insert Filters
    if filters:
        for f in filters:
            session.add(ReportFilter(
                report_id=report.report_id,
                filter_name=f["name"],
                db_column=f["db_column"],
                operator=f["operator"],
                input_type=f.get("input_type", "text")
            ))

    # 5. Insert Groupings
    if groupings:
        for g in groupings:
            session.add(ReportGrouping(
                report_id=report.report_id,
                db_column=g["db_column"],
                group_order=g.get("order", 0)
            ))

    # 6. Insert Orderings
    if orderings:
        for o in orderings:
            session.add(ReportOrdering(
                report_id=report.report_id,
                db_column=o["db_column"],
                sort_order=o["sort_order"]
            ))

    # 7. Insert Expressions (CASE, custom logic)
    if expressions:
        for e in expressions:
            session.add(ReportExpression(
                report_id=report.report_id,
                expr_alias=e["alias"],
                expression_sql=e["sql"],
                aggregation=e.get("aggregation"),
                display_order=e.get("order", 0)
            ))

    session.commit()
    return report.report_id

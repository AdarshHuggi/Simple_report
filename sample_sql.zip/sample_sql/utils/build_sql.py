
from datetime import datetime
from models.model import Report,ReportColumn, ReportJoin, ReportFilter,init_db
from models.model import ReportGrouping, ReportOrdering, ReportExpression


def build_report_sql(session, report_id, filters=None):
    """
    Build a SQL query dynamically from report metadata.
    :param session: SQLAlchemy session
    :param report_id: int - Report ID
    :param filters: dict - user-supplied filters {filter_name: value}
    :return: str - Generated SQL
    """
    filters = filters or {}

    # ---------------------
    # 1. Base report
    # ---------------------
    report = session.query(Report).filter(Report.report_id == report_id).first()
    if not report:
        raise ValueError(f"Report ID {report_id} not found")

    # ---------------------
    # 2. SELECT columns
    # ---------------------
    select_parts = []

    for col in sorted(report.columns, key=lambda c: c.display_order or 0):
        if col.aggregation:
            select_parts.append(f"{col.aggregation}({col.db_column}) AS \"{col.column_alias}\"")
        else:
            select_parts.append(f"{col.db_column} AS \"{col.column_alias}\"")

    for expr in sorted(report.expressions, key=lambda e: e.display_order or 0):
        if expr.aggregation:
            select_parts.append(f"{expr.aggregation}({expr.expression_sql}) AS \"{expr.expr_alias}\"")
        else:
            select_parts.append(f"{expr.expression_sql} AS \"{expr.expr_alias}\"")

    select_sql = ",\n    ".join(select_parts)

    # ---------------------
    # 3. FROM + JOINS
    # ---------------------
    join_sql = ""
    for j in report.joins:
        join_sql += f" {j.join_type} JOIN {j.right_table} ON {j.left_table}.{j.left_column} = {j.right_table}.{j.right_column}"

    from_sql = f"FROM {report.base_table}{join_sql}"

    # ---------------------
    # 4. WHERE filters
    # ---------------------
    where_parts = []
    for f in report.filters:
        if f.filter_name in filters:  # only apply if user supplied a value
            val = filters[f.filter_name]
            if isinstance(val, str):
                val = f"'{val}'"
            elif isinstance(val, (list, tuple)):
                val = "(" + ", ".join(f"'{v}'" if isinstance(v, str) else str(v) for v in val) + ")"
            where_parts.append(f"{f.db_column} {f.operator} {val}")

    where_sql = ""
    if where_parts:
        where_sql = "WHERE " + " AND ".join(where_parts)

    # ---------------------
    # 5. GROUP BY
    # ---------------------
    group_cols = [g.db_column for g in sorted(report.groupings, key=lambda g: g.group_order or 0)]
    if report.expressions:
        for expr in report.expressions:
            group_cols.append(expr.expression_sql)

    group_sql = ""
    if group_cols:
        group_sql = "GROUP BY " + ", ".join(group_cols)

    # ---------------------
    # 6. ORDER BY
    # ---------------------
    order_cols = [f"{o.db_column} {o.sort_order}" for o in report.orderings]
    order_sql = ""
    if order_cols:
        order_sql = "ORDER BY " + ", ".join(order_cols)

    # ---------------------
    # 7. Final SQL
    # ---------------------
    sql = f"""
        SELECT 
            {select_sql}
            {from_sql}
            {where_sql}
            {group_sql}
            {order_sql};
        """.strip()

    return sql

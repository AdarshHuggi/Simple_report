
from models.model import Report,ReportColumn, ReportJoin, ReportFilter,init_db
from models.model import ReportGrouping, ReportOrdering, ReportExpression

# Create report
report = Report(
    report_name="Sales by Customer",
    description="Shows total sales grouped by customer",
    base_table="customers"
)
#create session
Session = init_db()
session = Session()
session.add(report)
session.commit()

# Columns
col1 = ReportColumn(report_id=report.report_id, column_alias="Customer Name", db_column="c.customer_name", aggregation=None, display_order=1)
col2 = ReportColumn(report_id=report.report_id, column_alias="Total Sales", db_column="o.order_amount", aggregation="SUM", display_order=2)
session.add_all([col1, col2])

# Join (customers -> orders)
join1 = ReportJoin(report_id=report.report_id, join_type="INNER", left_table="customers", left_column="id", right_table="orders", right_column="customer_id")
session.add(join1)

# Filter (order date >= ...)
filter1 = ReportFilter(report_id=report.report_id, filter_name="Order Date", db_column="o.order_date", operator=">=", input_type="date")
session.add(filter1)

# Group by
group1 = ReportGrouping(report_id=report.report_id, db_column="c.customer_name", group_order=1)
session.add(group1)

# Order by (descending sales)
order1 = ReportOrdering(report_id=report.report_id, db_column="total_sales", sort_order="DESC")
session.add(order1)



expr1 = ReportExpression(
    report_id=report.report_id,
    expr_alias="Sales Category",
    expression_sql="CASE WHEN o.order_amount > 1000 THEN 'High' ELSE 'Low' END",
    aggregation=None,
    display_order=3
)
session.add(expr1)
session.commit()

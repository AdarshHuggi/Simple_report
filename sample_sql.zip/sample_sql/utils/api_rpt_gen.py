from fastapi import Query
from sqlalchemy.sql import text

@app.get("/reports/{report_id}/run")
def run_report(report_id: int, filters: dict = {}):
    session = SessionLocal()
    try:
        # Fetch report definition
        report = session.query(Report).filter(Report.report_id == report_id).first()
        if not report:
            raise HTTPException(status_code=404, detail="Report not found")

        # Build SELECT
        select_clauses = []
        for col in report.columns:
            if col.aggregation:
                select_clauses.append(f"{col.aggregation}({col.db_column}) AS \"{col.column_alias}\"")
            else:
                select_clauses.append(f"{col.db_column} AS \"{col.column_alias}\"")

        for expr in report.expressions:
            if expr.aggregation:
                select_clauses.append(f"{expr.aggregation}({expr.expression_sql}) AS \"{expr.expr_alias}\"")
            else:
                select_clauses.append(f"{expr.expression_sql} AS \"{expr.expr_alias}\"")

        select_sql = ", ".join(select_clauses) if select_clauses else "*"

        # Build FROM
        sql = f"SELECT {select_sql} FROM {report.base_table} "

        # Build JOINs
        for j in report.joins:
            sql += f"{j.join_type.upper()} JOIN {j.right_table} ON {j.left_table}.{j.left_column} = {j.right_table}.{j.right_column} "

        # Build WHERE
        where_clauses = []
        for f in report.filters:
            if f.filter_name in filters:
                user_val = filters[f.filter_name]
                where_clauses.append(f"{f.db_column} {f.operator} :{f.filter_name}")

        if where_clauses:
            sql += "WHERE " + " AND ".join(where_clauses) + " "

        # Build GROUP BY
        group_clauses = [g.db_column for g in report.groupings]
        if group_clauses:
            sql += "GROUP BY " + ", ".join(group_clauses) + " "

        # Build ORDER BY
        order_clauses = [f"{o.db_column} {o.sort_order}" for o in report.orderings]
        if order_clauses:
            sql += "ORDER BY " + ", ".join(order_clauses)

        # Execute query safely with parameters
        params = {f.filter_name: filters[f.filter_name] for f in report.filters if f.filter_name in filters}
        result = session.execute(text(sql), params).fetchall()

        # Format result as list of dicts
        rows = [dict(row._mapping) for row in result]

        return {
            "report_id": report_id,
            "report_name": report.report_name,
            "sql": sql,
            "params": params,
            "rows": rows
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        session.close()

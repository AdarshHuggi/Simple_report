from fastapi import FastAPI, HTTPException
from fastapi.routing import APIRouter
from models.model import init_db
from schemas.schema import ColumnSchema,JoinSchema,FilterSchema,GroupingSchema
from schemas.schema import OrderingSchema,ExpressionSchema,ReportSchema,ReportRequest
from datetime import datetime
from models.model import Report,ReportColumn, ReportJoin, ReportFilter,init_db
from models.model import ReportGrouping, ReportOrdering, ReportExpression
from utils.build_sql import build_report_sql


router = APIRouter(prefix="/reports", tags=["reports"])

SessionLocal = init_db()


def insert_report_metadata(session, payload: ReportSchema):
    # 1. Create Report
    report = Report(
        report_name=payload.report_name,
        description=payload.description,
        base_table=payload.base_table,
        is_active=True,
        created_at=datetime.now()
    )
    session.add(report)
    session.commit()

    # 2. Insert Columns
    for col in payload.columns:
        session.add(ReportColumn(
            report_id=report.report_id,
            column_alias=col.alias,
            db_column=col.db_column,
            aggregation=col.aggregation,
            display_order=col.order
        ))

    # 3. Insert Joins
    for j in payload.joins:
        session.add(ReportJoin(
            report_id=report.report_id,
            join_type=j.join_type,
            left_table=j.left_table,
            left_column=j.left_column,
            right_table=j.right_table,
            right_column=j.right_column
        ))

    # 4. Insert Filters
    for f in payload.filters:
        session.add(ReportFilter(
            report_id=report.report_id,
            filter_name=f.name,
            db_column=f.db_column,
            operator=f.operator,
            input_type=f.input_type
        ))

    # 5. Insert Groupings
    for g in payload.groupings:
        session.add(ReportGrouping(
            report_id=report.report_id,
            db_column=g.db_column,
            group_order=g.order
        ))

    # 6. Insert Orderings
    for o in payload.orderings:
        session.add(ReportOrdering(
            report_id=report.report_id,
            db_column=o.db_column,
            sort_order=o.sort_order
        ))

    # 7. Insert Expressions
    for e in payload.expressions:
        session.add(ReportExpression(
            report_id=report.report_id,
            expr_alias=e.alias,
            expression_sql=e.sql,
            aggregation=e.aggregation,
            display_order=e.order
        ))

    session.commit()
    return report.report_id




@router.post("/create-reports/")
def create_report(report: ReportSchema):
    session = SessionLocal()
    try:
        report_id = insert_report_metadata(session, report)
        return {"report_id": report_id, "message": "Report metadata inserted successfully"}
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        session.close()


@router.post("/generate-reports/")
def generate_report(report_request: ReportRequest):
    session = SessionLocal()
    try:
        # Logic to generate the report
        sql = build_report_sql(session, report_request.report_id, filters=report_request.filters)
        return {"sql": sql}
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        session.close()


@router.delete("/delete-reports/{report_id}")
def delete_report(report_id: int):
    session = SessionLocal()
    try:
        report = session.query(Report).filter(Report.report_id == report_id).first()
        if not report:
            raise HTTPException(status_code=404, detail="Report not found")

        session.delete(report)  # cascades to children
        session.commit()

        return {"message": f"Report {report_id} deleted successfully"}
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        session.close()
    #create report 
payload ={
  "report_name": "Sales by Customer",
  "description": "Shows total sales grouped by customer",
  "base_table": "customers",
  "columns": [
    {"alias": "Customer Name", "db_column": "c.customer_name", "order": 1},
    {"alias": "Total Sales", "db_column": "o.order_amount", "aggregation": "SUM", "order": 2}
  ],
  "joins": [
    {"join_type": "INNER", "left_table": "customers", "left_column": "id", "right_table": "orders", "right_column": "customer_id"}
  ],
  "filters": [
    {"name": "Order Date", "db_column": "o.order_date", "operator": ">=", "input_type": "date"}
  ],
  "groupings": [
    {"db_column": "c.customer_name", "order": 1}
  ],
  "orderings": [
    {"db_column": "total_sales", "sort_order": "DESC"}
  ],
  "expressions": [
    {"alias": "Sales Category", "sql": "CASE WHEN o.order_amount > 1000 THEN 'High' ELSE 'Low' END", "order": 3}
  ]
}


#generate_report
payload  ={
           "report_id": 1,
           "filters": {
             "Order Date": "2025-01-01",
             "Customer Name": "Alice"
           }
         }

"""
FastAPI SQL Query Builder — resilient version

Why this rewrite?
The original file imported FastAPI at module import time. In some sandboxed Python environments the `ssl` module is missing and that causes imports used by FastAPI/anyio/starlette to fail with `ModuleNotFoundError: No module named 'ssl'`.

What this file does now:
- Detects whether `ssl` and `fastapi` are available. If they are, the app behaves the same as before and exposes FastAPI endpoints.
- If `ssl` / `FastAPI` are NOT available, it falls back to a safe, local CLI/test mode that runs the same core logic (config store, query builder, and execution) without importing FastAPI or triggering the ssl-related import chain.
- Keeps the same SQL-building logic and safety checks (only SELECT, no semicolons, parameterized values).
- Adds a test suite (run automatically in fallback mode) that exercises common filters (=, >=, IN, LIKE, BETWEEN) so you can validate behavior in environments where FastAPI can't start.

Run:
- If your environment supports FastAPI and SSL: `python fastapi_sql_query_builder.py` will start uvicorn and open HTTP endpoints.
- If not: `python fastapi_sql_query_builder.py` will run the internal tests and print results.

Notes:
- In production you should still add authentication, rate-limiting, and a proper SQL parser for extra safety.
"""

from typing import Any, Dict, List, Optional, Tuple
import sqlite3
import json
import re
import os
import sys
import dataclasses
from dataclasses import dataclass, field, asdict, is_dataclass
import tempfile
import shutil

# ---------- Environment detection (ssl / FastAPI) ----------
try:
    import ssl  # may fail in some sandboxed environments
    SSL_AVAILABLE = True
except Exception as e:
    SSL_AVAILABLE = False
    ssl_import_error = e

FASTAPI_AVAILABLE = False
fastapi_import_error = None
# attempt lazy import of FastAPI and pydantic only if ssl is present
if SSL_AVAILABLE:
    try:
        from fastapi import FastAPI, HTTPException, Path
        from pydantic import BaseModel, Field
        FASTAPI_AVAILABLE = True
    except Exception as e:
        FASTAPI_AVAILABLE = False
        fastapi_import_error = e
else:
    fastapi_import_error = RuntimeError("ssl module is missing; skipping FastAPI import")

# ---------- Configuration (DB files) ----------
CONFIG_DB = "reports_config.db"       # stores report definitions
MAIN_DB = "main_data.db"             # the database where SELECTs are executed

# ensure DB files exist (but don't import FastAPI here)
for _f in (CONFIG_DB, MAIN_DB):
    if not os.path.exists(_f):
        open(_f, "a").close()

# ---------- DB connection helpers ----------

def get_config_conn():
    conn = sqlite3.connect(CONFIG_DB)
    conn.row_factory = sqlite3.Row
    return conn


def get_main_conn():
    conn = sqlite3.connect(MAIN_DB)
    conn.row_factory = sqlite3.Row
    return conn

# ensure the config table exists
def ensure_config_table():
    with get_config_conn() as c:
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                slug TEXT NOT NULL UNIQUE,
                config_json TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
            """
        )

ensure_config_table()

# ---------- Data classes (fallback-friendly) ----------
@dataclass
class FilterMappingData:
    column: str
    operator: str = "="
    required: bool = False
    type: Optional[str] = None

@dataclass
class ReportConfigData:
    report_name: str
    slug: str
    select_clause: str
    from_table: str
    joins: str = ""
    filter_mapping: Dict[str, FilterMappingData] = field(default_factory=dict)
    base_where: str = ""

# ---------- Helpers to normalize inputs (pydantic or dataclass or dict) ----------

def to_plain_dict(obj: Any) -> Dict[str, Any]:
    """Convert dataclass / pydantic model / dict into a plain dict."""
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    if is_dataclass(obj):
        return asdict(obj)
    if hasattr(obj, "dict"):
        # pydantic BaseModel
        try:
            return obj.dict()
        except Exception:
            return dict(obj.__dict__)
    # fallback
    return dict(obj.__dict__)


# small helper to raise appropriate error type depending on environment
def raise_bad_request(msg: str):
    if FASTAPI_AVAILABLE:
        # HTTPException is available
        raise HTTPException(status_code=400, detail=msg)
    else:
        raise ValueError(msg)

# ---------- Query building & safety ----------
ALLOWED_OPERATORS = {"=", ">", "<", ">=", "<=", "IN", "LIKE", "BETWEEN"}

SELECT_LEADING_RE = re.compile(r"^\s*SELECT\b", re.IGNORECASE)
SEMICOLON_RE = re.compile(r";")
COLUMN_NAME_RE = re.compile(r"^[A-Za-z0-9_\.]+$")  # allow dot for table.column


def validate_operator(op: str) -> str:
    if op is None:
        return "="
    if op.upper() not in ALLOWED_OPERATORS:
        raise_bad_request(f"Operator '{op}' is not allowed")
    return op.upper()


def enforce_select_only(sql: str):
    if not SELECT_LEADING_RE.search(sql):
        raise_bad_request("Only SELECT statements are allowed")
    if SEMICOLON_RE.search(sql):
        raise_bad_request("Multiple statements or semicolons are not allowed")


def sanitize_column_name(col: str) -> str:
    # very small sanitization: only allow letters/numbers/_ and optional dot for table.column
    if not isinstance(col, str) or not COLUMN_NAME_RE.match(col):
        raise_bad_request(f"Invalid column name: {col}")
    return col


def build_where_and_params(report_obj: Any, provided_filters: Dict[str, Any]) -> Tuple[str, List[Any]]:
    report = to_plain_dict(report_obj)
    where_parts: List[str] = []
    params: List[Any] = []

    # base where
    if report.get("base_where"):
        where_parts.append(f"({report.get('base_where')})")

    filter_mapping = report.get("filter_mapping") or {}

    for key, mapping in filter_mapping.items():
        m = to_plain_dict(mapping)
        # only consider if provided in request or required
        if key not in (provided_filters or {}):
            if m.get("required", False):
                raise_bad_request(f"Missing required filter: {key}")
            continue

        val = provided_filters.get(key)
        op = validate_operator(m.get("operator", "="))
        col = m.get("column")
        if not col:
            raise_bad_request(f"Filter mapping for '{key}' does not declare a 'column'")
        col = sanitize_column_name(col)

        if op == "IN":
            if not isinstance(val, (list, tuple)):
                raise_bad_request(f"Filter '{key}' requires a list for IN operator")
            if len(val) == 0:
                where_parts.append("1=0")
            else:
                placeholders = ",".join(["?" for _ in val])
                where_parts.append(f"{col} IN ({placeholders})")
                params.extend(val)

        elif op == "BETWEEN":
            if not (isinstance(val, (list, tuple)) and len(val) == 2):
                raise_bad_request(f"Filter '{key}' requires a two-element list for BETWEEN")
            where_parts.append(f"{col} BETWEEN ? AND ?")
            params.extend([val[0], val[1]])

        elif op == "LIKE":
            where_parts.append(f"{col} LIKE ?")
            params.append(str(val))

        else:
            # simple binary operator
            where_parts.append(f"{col} {op} ?")
            params.append(val)

    if where_parts:
        return " AND ".join(where_parts), params
    return "", []


def build_query(report_obj: Any, filters: Dict[str, Any], limit: Optional[int], offset: Optional[int]) -> Tuple[str, List[Any]]:
    report = to_plain_dict(report_obj)

    where_clause, params = build_where_and_params(report, filters or {})

    select_clause = report.get("select_clause", "*").strip()
    from_table = report.get("from_table")
    if not from_table:
        raise_bad_request("Report must declare 'from_table'")
    # sanitize basic table name (allow table or schema.table)
    _ = sanitize_column_name(from_table)

    joins_clause = (report.get("joins") or "").strip()

    sql = f"SELECT {select_clause} FROM {from_table}"
    if joins_clause:
        sql += f" {joins_clause}"

    if where_clause:
        sql += f" WHERE {where_clause}"

    if limit is not None:
        sql += " LIMIT ?"
        params.append(limit)
    if offset is not None and offset > 0:
        sql += " OFFSET ?"
        params.append(offset)

    enforce_select_only(sql)
    return sql, params

# ---------- Core operations (direct functions usable by both API and fallback) ----------

def insert_report_payload(payload: Dict[str, Any]) -> int:
    """Insert a report config dict into the config DB and return the new id."""
    # normalize keys: keep 'report_name' for legacy compatibility
    payload = dict(payload)
    if "report_name" not in payload and "name" in payload:
        payload["report_name"] = payload["name"]

    with get_config_conn() as c:
        try:
            c.execute(
                "INSERT INTO reports (name, slug, config_json) VALUES (?, ?, ?)",
                (payload.get("report_name"), payload.get("slug"), json.dumps(payload)),
            )
            c.commit()
            rid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            return int(rid)
        except sqlite3.IntegrityError as e:
            # rethrow as ValueError in fallback
            raise_bad_request(str(e))


def get_report_by_id(report_id: int) -> Dict[str, Any]:
    with get_config_conn() as c:
        r = c.execute("SELECT id, name, slug, config_json, created_at FROM reports WHERE id=?", (report_id,)).fetchone()
        if not r:
            if FASTAPI_AVAILABLE:
                raise HTTPException(status_code=404, detail="Report not found")
            else:
                raise KeyError("Report not found")
        cfg = json.loads(r["config_json"])
        return {"id": r["id"], "name": r["name"], "slug": r["slug"], "config": cfg, "created_at": r["created_at"]}


def run_report_direct(report_id: int, filters: Dict[str, Any] = None, limit: Optional[int] = 1000, offset: Optional[int] = 0) -> Dict[str, Any]:
    # load report
    with get_config_conn() as c:
        r = c.execute("SELECT config_json FROM reports WHERE id=?", (report_id,)).fetchone()
        if not r:
            if FASTAPI_AVAILABLE:
                raise HTTPException(status_code=404, detail="Report not found")
            else:
                raise KeyError("Report not found")
        cfg = json.loads(r["config_json"])

    sql, params = build_query(cfg, filters or {}, limit, offset)

    with get_main_conn() as m:
        cur = m.execute(sql, params)
        rows = [dict(row) for row in cur.fetchall()]
        columns = [d[0] for d in cur.description] if cur.description else []
        return {"query": sql, "params": params, "columns": columns, "rows": rows, "count": len(rows)}

# ---------- FastAPI endpoints (only defined when available) ----------
if FASTAPI_AVAILABLE:
    # use pydantic models for request validation
    class FilterMapping(BaseModel):
        column: str = Field(..., description="actual DB column name")
        operator: str = Field("=", description="operator, one of =, >, <, >=, <=, IN, LIKE, BETWEEN")
        required: bool = False
        type: Optional[str] = None

    class ReportConfig(BaseModel):
        report_name: str
        slug: str
        select_clause: str
        from_table: str
        joins: Optional[str] = ""
        filter_mapping: Dict[str, FilterMapping] = {}
        base_where: Optional[str] = ""

    class RunFilters(BaseModel):
        filters: Dict[str, Any] = {}
        limit: Optional[int] = 1000
        offset: Optional[int] = 0

    app = FastAPI(title="SQL Query Builder (FastAPI)")

    @app.post("/reports", summary="Create a new report config")
    def create_report(cfg: ReportConfig):
        # convert to dict and store
        payload = cfg.dict()
        # convert nested FilterMapping into simple dicts
        payload["filter_mapping"] = {k: v.dict() for k, v in cfg.filter_mapping.items()}
        rid = insert_report_payload(payload)
        return {"id": rid, "status": "created"}

    @app.get("/reports/{report_id}", summary="Get a report config")
    def get_report(report_id: int = Path(..., gt=0)):
        return get_report_by_id(report_id)

    @app.post("/reports/{report_id}/run", summary="Run a report with filters")
    def run_report(report_id: int, payload: RunFilters):
        return run_report_direct(report_id, payload.filters or {}, payload.limit, payload.offset)

# ---------- Convenience: seed example schema & data if empty ----------

def seed_main_db_if_empty():
    with get_main_conn() as c:
        tables = [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
        if "customers" in tables:
            return
        c.executescript(
            """
            CREATE TABLE customers (id INTEGER PRIMARY KEY, name TEXT, country TEXT, daily_sales REAL, created_at TEXT);
            INSERT INTO customers (name, country, daily_sales, created_at) VALUES
                ('Acme Corp', 'USA', 1200000, '2025-01-01'),
                ('Beta LLC', 'USA', 500000, '2025-02-01'),
                ('Gamma Ltd', 'UK', 1500000, '2025-03-01'),
                ('Delta Co', 'USA', 1000000, '2025-03-10'),
                ('Epsilon Inc', 'IN', 200000, '2025-04-01');
            """
        )

seed_main_db_if_empty()

# ---------- Tests (fallback-mode) ----------

def run_tests():
    print("Running internal tests in fallback mode...")
    # Use a temporary directory for DB files so we don't clobber user's DBs
    tempdir = tempfile.mkdtemp(prefix="query_builder_test_")
    global CONFIG_DB, MAIN_DB
    old_config_db, old_main_db = CONFIG_DB, MAIN_DB
    try:
        CONFIG_DB = os.path.join(tempdir, "reports_config.db")
        MAIN_DB = os.path.join(tempdir, "main_data.db")
        open(CONFIG_DB, "a").close()
        open(MAIN_DB, "a").close()

        ensure_config_table()
        seed_main_db_if_empty()

        # sample report config
        sample = {
            "report_name": "customer_sales",
            "slug": "customer_sales",
            "select_clause": "id, name, country, daily_sales",
            "from_table": "customers",
            "joins": "",
            "filter_mapping": {
                "country": {"column": "country", "operator": "=", "required": False},
                "min_daily_sales": {"column": "daily_sales", "operator": ">=", "required": False},
                "name_like": {"column": "name", "operator": "LIKE", "required": False},
                "countries": {"column": "country", "operator": "IN", "required": False},
                "sales_between": {"column": "daily_sales", "operator": "BETWEEN", "required": False},
            }
        }

        rid = insert_report_payload(sample)

        # Test 1: country = USA -> 3 rows
        res = run_report_direct(rid, {"country": "USA"})
        assert res["count"] == 3, f"Expected 3 rows for USA, got {res['count']}"

        # Test 2: min_daily_sales >= 1000000 -> 3 rows (Acme, Gamma, Delta)
        res = run_report_direct(rid, {"min_daily_sales": 1000000})
        assert res["count"] == 3, f"Expected 3 rows for >=1,000,000, got {res['count']}"

        # Test 3: country USA and min_daily_sales >= 1000000 -> 2 rows (Acme, Delta)
        res = run_report_direct(rid, {"country": "USA", "min_daily_sales": 1000000})
        assert res["count"] == 2, f"Expected 2 rows for USA >=1,000,000, got {res['count']}"

        # Test 4: IN operator -> countries IN (USA, UK) -> 4 rows
        res = run_report_direct(rid, {"countries": ["USA", "UK"]})
        assert res["count"] == 4, f"Expected 4 rows for IN (USA,UK), got {res['count']}"

        # Test 5: BETWEEN operator -> daily_sales BETWEEN 500000 AND 1200000 -> should include Beta(500k), Acme(1.2M), Delta(1.0M)
        res = run_report_direct(rid, {"sales_between": [500000, 1200000]})
        # Beta, Acme, Delta => 3 rows
        assert res["count"] == 3, f"Expected 3 rows for BETWEEN, got {res['count']}"

        # Test 6: LIKE operator
        res = run_report_direct(rid, {"name_like": "Acme%"})
        assert res["count"] == 1, f"Expected 1 row for LIKE Acme%, got {res['count']}"

        print("All tests passed ✅")
    finally:
        # restore global paths
        CONFIG_DB, MAIN_DB = old_config_db, old_main_db
        # cleanup
        try:
            shutil.rmtree(tempdir)
        except Exception:
            pass


# ---------- Run behavior ----------
if __name__ == "__main__":
    if FASTAPI_AVAILABLE:
        # start the uvicorn server
        print("FastAPI + SSL available. Starting app on http://127.0.0.1:8000 ...")
        try:
            import uvicorn
            uvicorn.run("fastapi_sql_query_builder:app" if __name__ != "__main__" else app, host="127.0.0.1", port=8000)
        except Exception as e:
            print("Failed to start uvicorn:", e)
            print("You can still use the module functions directly (insert_report_payload, run_report_direct, etc.)")
            sys.exit(1)
    else:
        print("FastAPI/SSL not available in this environment.")
        print("FastAPI import error:", repr(fastapi_import_error))
        print()
        # run fallback tests to validate functionality
        run_tests()
        print()
        print("Module loaded in fallback mode. You can call 'insert_report_payload' and 'run_report_direct' from Python to use the query builder directly.")

# End of file

from pydantic import BaseModel
from typing import List, Optional


class ColumnSchema(BaseModel):
    alias: Optional[str]
    db_column: str
    aggregation: Optional[str] = None
    order: Optional[int] = 0

class JoinSchema(BaseModel):
    join_type: str
    left_table: str
    left_column: str
    right_table: str
    right_column: str

class FilterSchema(BaseModel):
    name: str
    db_column: str
    operator: str
    input_type: Optional[str] = "text"

class GroupingSchema(BaseModel):
    db_column: str
    order: Optional[int] = 0

class OrderingSchema(BaseModel):
    db_column: str
    sort_order: str  # ASC or DESC

class ExpressionSchema(BaseModel):
    alias: str
    sql: str
    aggregation: Optional[str] = None
    order: Optional[int] = 0

class ReportSchema(BaseModel):
    report_name: str
    description: Optional[str]
    base_table: str
    columns: Optional[List[ColumnSchema]] = []
    joins: Optional[List[JoinSchema]] = []
    filters: Optional[List[FilterSchema]] = []
    groupings: Optional[List[GroupingSchema]] = []
    orderings: Optional[List[OrderingSchema]] = []
    expressions: Optional[List[ExpressionSchema]] = []

class ReportRequest(BaseModel):
    report_id: int
    filters: dict = {}
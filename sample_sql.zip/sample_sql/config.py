from typing import Dict, List, Any

# -----------------------------------------
# Report configurations (predefined SELECT, JOINs, mappings)
# -----------------------------------------
REPORT_CONFIGS = {
    "sales_report": {
        "base_table": "sales s",
        "select": [
            "s.id AS sale_id",
            "c.name AS customer_name",
            "p.name AS product_name",
            "s.amount",
            "s.date"
        ],
        "joins": [
            "INNER JOIN customers c ON s.customer_id = c.id",
            "INNER JOIN products p ON s.product_id = p.id"
        ],
        "filter_mapping": {
            "customer": "c.name",
            "product": "p.name",
            "min_amount": "s.amount >= {value}",
            "max_amount": "s.amount <= {value}",
            "date_from": "s.date >= '{value}'",
            "date_to": "s.date <= '{value}'"
        }
    },
    "inventory_report": {
        "base_table": "inventory i",
        "select": [
            "i.id AS inventory_id",
            "p.name AS product_name",
            "i.stock_quantity",
            "i.last_updated"
        ],
        "joins": [
            "INNER JOIN products p ON i.product_id = p.id"
        ],
        "filter_mapping": {
            "product": "p.name",
            "min_stock": "i.stock_quantity >= {value}",
            "max_stock": "i.stock_quantity <= {value}",
            "updated_after": "i.last_updated >= '{value}'"
        }
    }
}


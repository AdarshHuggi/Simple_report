from models.model import init_db
from models.model import Report
from routes.report_router import router
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn


# Initialize DB
Session = init_db()
session = Session()

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust origins as needed
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)

def main():
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)

if __name__ == "__main__":
    main()